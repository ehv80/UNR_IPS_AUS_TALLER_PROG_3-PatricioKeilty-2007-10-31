package myblog;

import java.util.Date;

public class Comment{
	private String _author = "anonymous";
	private String _message = "--blank comment--";
	private Date _creationDate = new Date();

	public Comment(){
	}
	
	public Comment(String author, String message){
		_author = author;
		_message = message;
	}
	
	public String getAuthor(){
		return _author;
	}
	public void setAuthor(String author){
	    _author = author;
	}
	public String getMessage(){
		return _message;
	}
	public void setMessage(String message){
		_message = message;
	}

	public Date getCreationDate(){
		return _creationDate ;
	}
}
